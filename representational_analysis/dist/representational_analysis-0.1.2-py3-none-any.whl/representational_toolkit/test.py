# import pyotp

# key = 'CL6QWHWTPIQX6UZB4X7SJF5GILCM3SAK'
# totp = pyotp.TOTP(key)
# print(totp.now())